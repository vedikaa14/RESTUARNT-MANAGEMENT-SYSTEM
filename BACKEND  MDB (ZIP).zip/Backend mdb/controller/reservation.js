import ErrorHandler from "../error/error.js";     
import Reservation from "../models/reservationschema.js";

export const createReservation = async (req, res, next) => {
    
        const { firstname, lastname, email, phone, reservationDate, numberOfGuests, time } = req.body;
        
        if (!firstname || !lastname || !email || !phone || !reservationDate || !numberOfGuests || !time) {
            return next(new ErrorHandler("All fields are required", 400));
        }
        try {
            await Reservation.create({
                firstname,
                lastname,
                email,
                phone,
                reservationDate,
                numberOfGuests,
                time
            });
            res.status(200).json({ message: "Reservation created successfully" });

         } catch (error) {
            if (error.name === 'ValidationError') {
                const validatorErrors = Object.values(error.errors).map(err => err.message);
                return next(new ErrorHandler(validatorErrors.join(', '), 400));
            }
    }
};
