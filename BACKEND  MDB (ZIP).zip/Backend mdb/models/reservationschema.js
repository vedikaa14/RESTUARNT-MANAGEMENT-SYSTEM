import mongoose from "mongoose";

const reservationSchema = new mongoose.Schema({
  firstname: {
    type: String,
    required: [true, "First name is required"],
    minlength: [3, "First name must be at least 3 characters long"],
  },
  lastname: {
    type: String,
    required: [true, "Last name is required"],
    minlength: [3, "Last name must be at least 3 characters long"],
  },
  email: {
    type: String,
    required: [true, "Email is required"],
  },
  phone: {
    type: String,
    required: [true, "Phone number is required"],
  },
  reservationDate: {
    type: Date,
    required: [true, "Reservation date is required"],
  },
  numberOfGuests: {
    type: Number,
    required: [true, "Number of guests is required"],
  },
  time: {
    type: String,
    required: [true, "Time is required"],
  },
});

const Reservation = mongoose.model("Reservation", reservationSchema);
export default Reservation;
